// C++ program to implement Quick Hull algorithm
// to find convex hull.
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>


typedef struct point
{
    double x, y, angle;
} Point;

int orientation(Point p1, Point p2, Point p)
{
    int val = (p.y - p1.y) * (p2.x - p1.x) -
              (p2.y - p1.y) * (p.x - p1.x);

    if (val > 0)
    {
        return 1;
    }
    if (val < 0)
    {
        return -1;
    }
    return 0;
}

// returns a value proportional to the distance
// between the point p and the line joining the
// points p1 and p2
int dist(Point p1, Point p2, Point p)
{
    return abs((p.y - p1.y) * (p2.x - p1.x) -
               (p2.y - p1.y) * (p.x - p1.x));
}

double pointDist(Point a, Point b)
{
    double xsqr = a.x - b.x;
    xsqr = xsqr * xsqr;
    double ysqr = a.y - b.y;
    ysqr = ysqr * ysqr;
    // printf("dist (%.1lf,%.1lf) -> (%.1lf,%.1lf) = %.1lf\n", a.x, a.y, b.x, b.y, sqrt(xsqr + ysqr));
    return sqrt(xsqr + ysqr);
}

int insertHull(Point **hull, int *index, Point p)
{
    for (int i = 0; i < *index; i++)
    {
        double x = ((*hull)[i]).x;
        double y = ((*hull)[i]).y;

        if (p.x == x && p.y == y)
        {
            return -1;
        }
    }

    ((*hull)[*index]).x = p.x;
    ((*hull)[*index]).y = p.y;
    (*index) = (*index) + 1;
    return 0;
}

// End points of line L are p1 and p2. side can have value
// 1 or -1 specifying each of the parts made by the line L
double quickHull(Point *a, int n, Point p1, Point p2, int side, Point **hull, int *index)
{
    int ind = -1;
    int max_dist = 0;
    double pointsDist = 0;

    // finding the point with maximum distance
    // from L and also on the specified side of L.
    for (int i = 0; i < n; i++)
    {
        int temp = dist(p1, p2, a[i]);
        if (orientation(p1, p2, a[i]) == side && temp > max_dist)
        {
            ind = i;
            max_dist = temp;
        }
    }

    // If no point is found, add the end points
    // of L to the convex hull.
    if (ind == -1)
    {

        insertHull(hull, index, p1);
        insertHull(hull, index, p2);
        return pointDist(p1, p2);
    }

    // Recur for the two parts divided by a[ind]
    pointsDist += quickHull(a, n, a[ind], p1, -orientation(a[ind], p1, p2), hull, index);
    pointsDist += quickHull(a, n, a[ind], p2, -orientation(a[ind], p2, p1), hull, index);
    return pointsDist;
}

int main()
{
    int n = 30000;
    Point s1;
    s1.x = 145.7;
    s1.y = 517.0;
    Point s2;
    s2.x = 5961.6;
    s2.y = 6274.5;

    printf("Enter s1 x coordinate\n");
    scanf("%lf",&(s1.x));
    printf("Enter s1 y coordinate\n");
    scanf("%lf",&(s1.y));

    printf("Enter s2 x coordinate\n");
    scanf("%lf",&(s2.x));
    printf("Enter s2 y coordinate\n");
    scanf("%lf",&(s2.y));

    Point *array = malloc(sizeof(Point) * n);
    Point *hull = malloc(sizeof(Point) * n);
    int index = 0;
    int i = 0;

    FILE *fp = fopen("data_A2_Q2.txt", "r");
    while (!feof(fp))
    {
        fscanf(fp, "%lf %lf ", &(array[i].x), &(array[i].y));
        i++;
    }
    fclose(fp);

    int minX = 0;
    int maxX = 0;

    clock_t t;
    t = clock();
    for (int i = 1; i < n; i++)
    {
        if (array[i].x < array[minX].x)
            minX = i;
        if (array[i].x > array[maxX].x)
            maxX = i;
    }
    double dist1 = 0;
    double dist2 = 0;

    dist1 = quickHull(array, n, array[minX], array[maxX], 1, &hull, &index);
    dist2 = quickHull(array, n, array[minX], array[maxX], -1, &hull, &index);

    Point *path1 = malloc(sizeof(Point) * index);

    int s1i = 0;
    int s2i = 0;

    for (int i = 0; i < index; i++)
    {
        if (hull[i].x == s1.x && hull[i].y == s1.y)
        {
            s1i = i;
        }
        if (hull[i].x == s2.x && hull[i].y == s2.y)
        {

            s2i = i;
        }
    }
    int index2 = 0;
    // printf("\n\n\n");
    dist1 = quickHull(hull, index, hull[s1i], hull[s2i], 1, &path1, &index2);
    // printf("\n\n\n");
    dist2 = quickHull(hull, index, hull[s1i], hull[s2i], -1, &path1, &index2);
    double time_taken = ((double)t) / CLOCKS_PER_SEC;
    double shortest = dist1 < dist2 ? dist1 : dist2;

    printf("shortest distance %lf\n", shortest);
    printf("exec time %f\n", time_taken);

    free(array);
    free(hull);
    free(path1);

    return 0;
}
