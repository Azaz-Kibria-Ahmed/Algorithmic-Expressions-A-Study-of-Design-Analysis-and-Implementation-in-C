#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int i = 0;
    int j = 0;
    int n = 50000;
    int inversions=0;
    FILE *fp = fopen("data_A2_Q1.txt", "r");
    unsigned int *array = malloc(sizeof(unsigned int) * n);
    while (!feof(fp))
    {
        fscanf(fp, "%d", &(array[i]));
        i++;
    }
    fclose(fp);

    clock_t t;
    t = clock();
    
    for (i = 0; i < n - 1; i++)
    {

        for (j = 0; j < n - i - 1; j++)
        {
            if (array[j] > array[j + 1])
            {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
                inversions++;
            }
        }
    }

    t = clock() - t;
    double time_taken = ((double)t) / CLOCKS_PER_SEC; 

    // for(i=0;i<n;i++)
    //     printf("%d\n",array[i]);
    printf("exec time %f with %d inversions \n", time_taken,inversions);
    
    free(array);
    return 0;
}
