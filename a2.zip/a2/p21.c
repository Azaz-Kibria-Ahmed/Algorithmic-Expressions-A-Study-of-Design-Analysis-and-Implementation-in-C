#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

typedef struct point
{
    double x, y;
} Point;

double pointDist(Point a, Point b)
{
    double xsqr = a.x - b.x;
    xsqr = xsqr * xsqr;
    double ysqr = a.y - b.y;
    ysqr = ysqr * ysqr;
    return sqrt(xsqr + ysqr);
}

int orientation(Point a, Point b, Point c)
{
    int res = (b.y - a.y) * (c.x - b.x) - (b.x - a.x) * (c.y - b.y);
    if (res == 0)
    {
        return res;
    }
    return (res > 0) ? 1 : -1; // clock or counterclock wise
}
// Prints convex hull of a set of n points
void convexHull(Point *points, int n, Point s1, Point s2)
{
    clock_t t;
    t = clock();

    Point *posts = malloc(sizeof(Point) * n);
    int postCount = 0;
    int lmIndex = 0;
    for (int i = 0; i < n; i++)
    {
        lmIndex = points[i].x < points[lmIndex].x ? i : lmIndex;
    }
    // printf("left most %.1lf,%.1lf\n", points[lmIndex].x, points[lmIndex].y);
    int a = lmIndex;
    int b = 0;
    do
    {
        posts[postCount].x = points[a].x;
        posts[postCount].y = points[a].y;
        postCount++;
        b = (a + 1) % n;
        for (int i = 0; i < n; i++)
        {
            if (orientation(points[a], points[i], points[b]) == -1)
            {
                b = i;
            }
        }
        a = b;
    } while (a != lmIndex);

    double shortestPath = 0;
    int s1Index = -1;
    int s2Index = -1;
    for (int i = 0; i < postCount; i++)
    {
        // printf("[%d\n]", i);
        // printf("%.1lf,%.1lf\n", posts[i].x, posts[i].y);
        if (posts[i].x == s1.x && posts[i].y == s1.y)
        {
            s1Index = i;
        }
        if (posts[i].x == s2.x && posts[i].y == s2.y)
        {
            s2Index = i;
        }
    }

    double distCW = 0;
    double distACW = 0;

    // for(int i = s1Index; i<s2Index;i++){
    int i = s1Index;
    while (1)
    {
        if (i == s2Index)
        {
            break;
        }
        // printf("(%.1lf,%.1lf) -> (%.1lf,%.1lf)\n", posts[i].x, posts[i].y, posts[i + 1].x, posts[i + 1].y);
        distACW += pointDist(posts[i], posts[i + 1]);
        i++;
        if (i == postCount)
        {
            i = 0;
        }
    }
    // printf("\n\n\n");

    i = s1Index;
    while (1)
    {
        if (i == s2Index)
        {
            break;
        }
        // printf("[%d]  (%.1lf,%.1lf) -> (%.1lf,%.1lf)\n", i, posts[i].x, posts[i].y, posts[i - 1].x, posts[i - 1].y);
        distCW += pointDist(posts[i], posts[i - 1]);
        i--;
        if (i == 0)
        {
            // printf("[%d]  (%.1lf,%.1lf) -> (%.1lf,%.1lf)\n", i, posts[i].x, posts[i].y, posts[postCount - 1].x, posts[postCount - 1].y);
            distCW += pointDist(posts[i], posts[postCount - 1]);
            i = postCount - 1;
        }
    }

    shortestPath = distCW < distACW ? distCW : distACW;
    // printf("s1i:%d    s2i:%d\n", s1Index, s2Index);
    // printf("total points %d\n", postCount);
    // printf("cw %lf\n", distCW);
    // printf("acw %lf\n", distACW);
    // printf("last post %.1lf %.1lf \n", posts[postCount - 1].x, posts[postCount - 1].y);
    int pathPoints = 0;
    if (shortestPath == distCW)
    {
        i = s1Index;
        while (1)
        {
            pathPoints++;
            if (i == s2Index)
            {
                break;
            }
            printf("( %.1lf,%.1lf )\n", posts[i].x, posts[i].y);
            distCW += pointDist(posts[i], posts[i - 1]);
            i--;
            if (i == 0)
            {
                printf("( %.1lf,%.1lf )\n", posts[i].x, posts[i].y);
                distCW += pointDist(posts[i], posts[postCount - 1]);
                i = postCount - 1;
            }
        }
    }
    else
    {
        i = s1Index;
        while (1)
        {
            pathPoints++;
            if (i == s2Index)
            {
                break;
            }
            printf("( %.1lf,%.1lf )\n", posts[i].x, posts[i].y);
            distACW += pointDist(posts[i], posts[i + 1]);
            i++;
            if (i == postCount)
            {
                i = 0;
            }
        }
    }
    printf("Number of points  %d\n", pathPoints + 1);
    printf("shortest distance  %lf\n", shortestPath);
    double time_taken = ((double)t) / CLOCKS_PER_SEC;
    printf("exec time %f\n", time_taken);
    free(posts);
}

int main()
{
    int n = 30000;
    Point s1;
    s1.x = 145.7;
    s1.y = 517.0;
    Point s2;
    s2.x = 5961.6;
    s2.y = 6274.5;

    printf("Enter s1 x coordinate\n");
    scanf("%lf", &(s1.x));
    printf("Enter s1 y coordinate\n");
    scanf("%lf", &(s1.y));

    printf("Enter s2 x coordinate\n");
    scanf("%lf", &(s2.x));
    printf("Enter s2 y coordinate\n");
    scanf("%lf", &(s2.y));

    Point *array = malloc(sizeof(Point) * n);
    int i = 0;
    FILE *fp = fopen("data_A2_Q2.txt", "r");
    while (!feof(fp))
    {
        fscanf(fp, "%lf %lf ", &(array[i].x), &(array[i].y));
        i++;
    }
    fclose(fp);

    convexHull(array, n, s1, s2);

    return 0;
}
