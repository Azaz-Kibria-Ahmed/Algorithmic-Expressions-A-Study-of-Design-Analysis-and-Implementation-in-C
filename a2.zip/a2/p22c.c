#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_POINTS 30000
#define MAX_HULL_POINTS MAX_POINTS

struct Point
{
    double x;
    double y;
};

double cross_product(struct Point A, struct Point B, struct Point C)
{
    double ABx = B.x - A.x;
    double ABy = B.y - A.y;
    double ACx = C.x - A.x;
    double ACy = C.y - A.y;

    return ABx * ACy - ABy * ACx;
}

double distance(struct Point A, struct Point B)
{
    double dx = B.x - A.x;
    double dy = B.y - A.y;

    return sqrt(dx * dx + dy * dy);
}

void quickhull(struct Point points[], int n, struct Point hull[], int *hull_size)
{
    if (n < 3)
    {
        return;
    }

    int min_x = 0, max_x = 0;
    for (int i = 1; i < n; i++)
    {
        if (points[i].x < points[min_x].x)
        {
            min_x = i;
        }
        else if (points[i].x > points[max_x].x)
        {
            max_x = i;
        }
    }

    struct Point A = points[min_x];
    struct Point B = points[max_x];
    hull[(*hull_size)++] = A;
    hull[(*hull_size)++] = B;

    struct Point left[MAX_POINTS], right[MAX_POINTS];
    int left_size = 0, right_size = 0;

    for (int i = 0; i < n; i++)
    {
        if (i == min_x || i == max_x)
        {
            continue;
        }

        double cp = cross_product(A, B, points[i]);
        if (cp < 0)
        {
            left[left_size++] = points[i];
        }
        else if (cp > 0)
        {
            right[right_size++] = points[i];
        }
    }

    quickhull(left, left_size, hull, hull_size);
    quickhull(right, right_size, hull, hull_size);
}

int main()
{
    int n = 30000;
    struct Point *array = malloc(sizeof(struct Point) * n);
    int i = 0;
    FILE *fp = fopen("data_A2_Q2.txt", "r");
    while (!feof(fp))
    {
        fscanf(fp, "%lf %lf ", &(array[i].x), &(array[i].y));
        i++;
    }
    fclose(fp);

    struct Point hull[MAX_HULL_POINTS];
    int hull_size = 0;
    quickhull(array, n, hull, &hull_size);
}
